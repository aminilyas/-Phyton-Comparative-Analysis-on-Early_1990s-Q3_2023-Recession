# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 18:55:50 2022

@author: moham
"""

import pandas as pd
import numpy as np
from scipy import stats
from matplotlib import pyplot as plt
import seaborn as sns
from scipy.stats.mstats import winsorize

sns.set()     # better looking figures

# change to the path of your working directory
inputPath ='C:\Users\moham\Downloads'
# inputPath = 'D:/OneDrive - NEOMA Business School/MSc_Financial_Markets_&_Technologies/Courses S1/Course Data Visulization/codes'

'''
First, we read each data file and do some cleaning.
Second, we create two columns, year and month for each from the date variable.
We can use the apply method for the Pandas dataframe object.
'''

# load the industry stock return data 
fileName = 'C:/Users/moham/Downloads/1989-1990.csv'
df1 = pd.read_csv('C:/Users/moham/Downloads/20py6a5dvcq95nlx.csv')
secNames = df1['FFI10_desc'].unique()     # sector names
df1['public_date'] = pd.to_datetime(df1['public_date'])      # convert date first
dates = df1.public_date.unique()    # dates
df1['divyield_Mean'] = df1['divyield_Mean'].str.rstrip('%').astype('float')/100      # remove the % sign
# the following two lines access the year and month information from the pandas datetime object
df1['year'] = df1['public_date'].apply(lambda x: x.year)
df1['month'] = df1['public_date'].apply(lambda x: x.month)
df1['indret_vw'] = (df1['indret_vw']-df1['indret_vw'].mean())/df1['indret_vw'].std()      # standardize the series: substract the mean and divide by standard deviation
# drop some columns
cols2drop = ['public_date']
df1 = df1.drop(columns=cols2drop)

# load industrial production, the data looks like to be nonstationary on the website, so we use log difference
fileName = inputPath+'/INDPRO (2).csv'
df2 = pd.read_csv('C:/Users/moham/Downloads/INDPRO (3).csv')
df2['DATE'] = pd.to_datetime(df2['DATE'])      # convert date
df2['ipg'] = np.log(df2['INDPRO']/df2['INDPRO'].shift())     # use log growth due to nonstationarity
df2['ipg'] = (df2['ipg']-df2['ipg'].mean())/df2['ipg'].std()    # standardize the series: substract the mean and divide by standard deviation
df2['year'] = df2['DATE'].apply(lambda x: x.year)
df2['month'] = df2['DATE'].apply(lambda x: x.month)
# drop some columns
cols2drop = ['DATE', 'INDPRO']
df2 = df2.drop(columns=cols2drop)

# load unemployment rate, looks stationary
fileName = inputPath+'/UNRATE.csv'
df3 = pd.read_csv('C:/Users/moham/Downloads/UNRATE (2).csv')
df3['DATE'] = pd.to_datetime(df3['DATE'])      # convert date
df3['year'] = df3['DATE'].apply(lambda x: x.year)
df3['month'] = df3['DATE'].apply(lambda x: x.month)
df3['unrate'] = (df3['UNRATE']-df3['UNRATE'].mean())/df3['UNRATE'].std()    # standardize the series: substract the mean and divide by standard deviation
# drop some columns
cols2drop = ['DATE', 'UNRATE']
df3 = df3.drop(columns=cols2drop)

# load consumer price index, the data looks like to be nonstationary on the website, so we use log difference
fileName = inputPath+'/USACPICORMINMEI.csv'
df4 = pd.read_csv('C:/Users/moham/Downloads/USACPICORMINMEI (2).csv')
df4['DATE'] = pd.to_datetime(df4['DATE'])      # convert date
df4['cpig'] = np.log(df4['USACPICORMINMEI']/df4['USACPICORMINMEI'].shift())     # use log growth due to nonstationarity
df4['cpig'] = (df4['cpig']-df4['cpig'].mean())/df4['cpig'].std()    # standardize the series: substract the mean and divide by standard deviation
df4['year'] = df4['DATE'].apply(lambda x: x.year)
df4['month'] = df4['DATE'].apply(lambda x: x.month)
# drop some columns
cols2drop = ['DATE', 'USACPICORMINMEI']
df4 = df4.drop(columns=cols2drop)

# load FFR, looks stationary
fileName = inputPath+'/DFF.csv'
df5 = pd.read_csv('C:/Users/moham/Downloads/FEDFUNDS (2).csv')
df5['DATE'] = pd.to_datetime(df5['DATE'])      # convert date
df5['year'] = df5['DATE'].apply(lambda x: x.year)
df5['month'] = df5['DATE'].apply(lambda x: x.month)
df5 = df5.rename(columns={"FEDFUNDS": "ffr"})
df5['ffr'] = (df5['ffr']-df5['ffr'].mean())/df5['ffr'].std()    # standardize the series: substract the mean and divide by standard deviation
# drop some columns
cols2drop = ['DATE']
df5 = df5.drop(columns=cols2drop)

# load EPU, looks stationary. 
fileName = inputPath+'/USEPUINDXM.csv'
df6 = pd.read_csv('C:/Users/moham/Downloads/USEPUINDXM (2).csv')
df6['DATE'] = pd.to_datetime(df6['DATE'])      # convert date
df6['year'] = df6['DATE'].apply(lambda x: x.year)
df6['month'] = df6['DATE'].apply(lambda x: x.month)
df6['epu'] = (df6['USEPUINDXM']-df6['USEPUINDXM'].mean())/df6['USEPUINDXM'].std()    # standardize the series: substract the mean and divide by standard deviation
# drop some columns
cols2drop = ['DATE', 'USEPUINDXM']
df6 = df6.drop(columns=cols2drop)

'''
We merge df1 with df2--6 by year and month.
We still want to use inner join, keep the observations common in both the left and right dataframes.
'''
df12 = pd.merge(df1, df2, how="left", on=['year','month'])
df13 = pd.merge(df12, df3, how="left", on=['year','month'])
df14 = pd.merge(df13, df4, how="left", on=['year','month'])
df15 = pd.merge(df14, df5, how="left", on=['year','month'])
df16 = pd.merge(df15, df6, how="left", on=['year','month'])

#%%
'''
plot the industry return dynamics with subplots
%matplotlib qt
'''
dpi = 200       # resolution of the graph
lw = 1.5          # linewidth
fts = 12       # font size
lsty = ['solid','dotted', 'dashed', 'dashdot']          # line styles
cl = ['black','blue', 'red']        # line colors

x = 1989+1/12*np.arange(24)     # 444 months between 19985.01 and 2021.12
xtc = x[::60]

fts2 = 12
key = 'indret_vw'
keyMs = ['ipg', 'unrate', 'cpig', 'ffr', 'epu']
keyM = keyMs[4]    # do it one at a time by changing the number
for i in range(10):
    temp = df16[df16['FFI10_desc']==secNames[i]]
    plt.subplot(5,2,i+1)
    plt.plot(x, temp[key], label=secNames[i])
    plt.plot(x, temp[keyM], label = keyM)
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate(r'$\rho$ = '+str(round(np.corrcoef(temp[key], temp[keyM])[0,1], 2)), xytext=[1990, temp[key].max()*0.9], xy=[1990, temp[key].max()*0.9], fontsize=fts2)     
    plt.grid(True)

'''
seaborn plotting
'''
sns.set(font_scale=2)    # increase the font size

# a box plot
sns.boxplot(data = df16, x = 'indret_vw', y = 'FFI10_desc')
# a violin plot
sns.violinplot(data=df16, x = 'indret_vw', y = 'FFI10_desc')

'''
use the jointplot function from seaborn
'''
# first, for durable sector and ipg
keyM = keyMs[0]
temp = df16[df16['FFI10_desc']==secNames[0]]
# seaborn scatter plot
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'scatter')
# second, for energy and ipg, increase the histogram bins
temp = df16[df16['FFI10_desc']==secNames[1]]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'scatter', marginal_kws=dict(bins=100))      
# 3rd, Hitech and ipg, add the scale for the histogram
temp = df16[df16['FFI10_desc']==secNames[2]]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'scatter', marginal_ticks=True)      
# 4th, health and ipg, use kernel density
temp = df16[df16['FFI10_desc']==secNames[3]]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'kde', marginal_ticks=True)     
# 5th, manufactor and ipg, histogram
temp = df16[df16['FFI10_desc']==secNames[4]]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'hist', marginal_ticks=True)     
# 6th, nondurable and ipg, hexagonal
temp = df16[df16['FFI10_desc']==secNames[5]]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'hex', marginal_ticks=True)     
# 7th, shops and ipg, add regression
temp = df16[df16['FFI10_desc']==secNames[7]]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'reg', marginal_ticks=True) 
# 8th, plot TELCM, UTILS in one graph, use the isin method to select the subset
secs = ['TELCM', 'UTILS']
temp = df16[df16.FFI10_desc.isin(secs)]
g = sns.jointplot(data = temp, x = key, y = keyM, kind = 'scatter', hue= 'FFI10_desc')   