# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 10:59:09 2022
This one makes the graphs for lecture 2
@author: wenbin.cao
"""
import pandas as pd
import numpy as np
from scipy import stats
from matplotlib import pyplot as plt
import seaborn as sns
from scipy.stats.mstats import winsorize

# change to the path of your working directory
# inputPath = 'C:/Users/wenbin.cao/OneDrive - NEOMA Business School/MSc_Financial_Markets_&_Technologies/Courses S1/Course Data Visulization/codes'
inputPath = 'C:/Users/amin/OneDrive/IEMBA MSC NEOMA BS/8 Financial Data Visualization'

fileName = inputPath+'/FDV3.csv'
df1 = pd.read_csv(fileName, sep=",") #Amin doesnt matter xls or csv
colNames = df1.columns #Amin column names
secNames = df1['FFI10_desc'].unique()     # sector names
df1['public_date'] = pd.to_datetime(df1['public_date'])      # convert date 
dates = df1.public_date.unique()    # dates
df1['divyield_Mean'] = df1['divyield_Mean'].str.rstrip('%').astype('float')/100      # remove the % sign #Amin to conert to actual number

sns.set()     # better looking figures
#%%
'''
This part plots the cross section
Select the first/last month
'''
i = -1    # select the month
temp = df1[df1['public_date']==dates[i]].copy()    # return a copy not a view
temp['Industry'] = np.arange(1,11)    #Industry indicator
temp['Percent'] = temp['NFIRM']/temp['NFIRM'].sum()*100

# %matplotlib qt
dpi = 200       # resolution of the graph
fts = 12       # font size

# the number of firms
fts2 = 15
y_pos = temp['Industry']
plt.barh(y_pos, temp['NFIRM']) #Amin to setup number of firm
plt.yticks(y_pos, temp['FFI10_desc'], fontsize = fts2)
plt.xticks(fontsize = fts2)

# a pie chart for percentage
plt.figure(dpi = dpi)
plt.pie(temp['Percent'], labels=temp['FFI10_desc'], autopct='%1.1f%%', shadow=True, radius=1.5)
plt.axis('equal')

#%%
'''
plot the time series jointly
%matplotlib qt
'''
dpi = 200       # resolution of the graph
lw = 1.5          # linewidth
fts = 12       # font size
lsty = ['solid','dotted', 'dashed', 'dashdot']          # line styles
cl = ['black','blue', 'red']        # line colors
x = 1970+1/12*np.arange(len(dates))
xtc = x[::60]

# plot the number of firms evolution
key = 'NFIRM'
plt.figure(dpi = dpi)
for i in range(len(secNames)):
    temp = df1[df1['FFI10_desc']==secNames[i]]    
    plt.plot(x, temp[key], label=secNames[i])
plt.xlabel(r'Year', fontsize =fts)    
plt.ylabel(r'Firm Number', fontsize =fts)
plt.yticks(fontsize=fts)
plt.xticks(xtc, fontsize=fts)
plt.legend(fontsize = fts, ncol=2)
plt.grid(True)


# plot the industry return dynamics with subplots
fts2 = 10
key = 'indret_vw'
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    plt.subplot(5,2,i+1)
    plt.plot(x, temp[key], label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(temp[key].mean()*12, 2)), xytext=[1985, temp[key].max()*0.9], xy=[1985, temp[key].max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(temp[key].std()*np.sqrt(12), 2)), xytext=[2005, temp[key].max()*0.9], xy=[2005, temp[key].max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot the bm_Mean
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['bm_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)
    
# plot the dividend yield mean
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['divyield_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1980, yW.max()*0.9], xy=[1980, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot the mean gross profit margin
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['gpm_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)
    
# plot the mean return on assets
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]    
    y = temp['roa_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)
    
# plot the total debt to investment capital
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['totdebt_invcap_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

#Amin
# plot the mean price to cash flow (PCF)
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['pcf_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot the mean price to sales (PS)
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['ps_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot the mean price to book value (PTB)
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['ptb_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot price to effective tax rate
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['efftax_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)
    
# plot price to net profit margin
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['npm_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot price to Return on Capital Employed (ROCE)
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['roce_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)

# plot price to Return on Equity (ROE)
fts2 = 10
for i in range(10):
    temp = df1[df1['FFI10_desc']==secNames[i]]
    y = temp['roe_Mean']
    yW = winsorize(y, limits=[0, 0.01])
    plt.subplot(5,2,i+1)
    plt.plot(x, yW, label=secNames[i])
    plt.legend(fontsize = fts2)
    plt.yticks(fontsize=fts2)
    plt.xticks(xtc, fontsize=fts2)
    plt.annotate('Mean='+str(round(yW.mean(), 2)), xytext=[1995, yW.max()*0.9], xy=[1995, yW.max()*0.9], fontsize=fts2)     
    plt.annotate('S.D.='+str(round(yW.std(), 2)), xytext=[2003, yW.max()*0.9], xy=[2003, yW.max()*0.9], fontsize=fts2)
    plt.grid(True)
#%%
'''
This part does pair-wise scatter-plots for industry return and industry characteristics.
'''
y = df1['indret_vw']

# use only one x at a time
x = df1['bm_Mean']
x = df1['divyield_Mean']
x = df1['gpm_Mean']
x = df1['roa_Mean']
x = df1['totdebt_invcap_Mean']
#Amin
x = df1['pcf_Mean']
x = df1['ps_Mean']
x = df1['ptb_Mean']
x = df1['efftax_Mean']
x = df1['npm_Mean']
x = df1['roce_Mean']
x = df1['roe_Mean']

xW = winsorize(x, limits=[0.005, 0.005])

fts = 15
plt.figure(dpi = dpi)
plt.scatter(xW, y, c="g", label='Data')
m, b = np.polyfit(xW, y, 1)
plt.plot(xW, m*xW+b, label='Fitted', linewidth=lw, color='r')
plt.xlabel(x.name, fontsize =fts)    
plt.ylabel(y.name, fontsize =fts)
plt.yticks(fontsize=fts)
plt.xticks(fontsize=fts)
plt.legend(fontsize = fts)
# this depends on the x
plt.annotate('Intercept='+str(round(m*100, 2))+'%', xytext=[xW.max()*0.5, y.max()*0.9], xy=[xW.max()*0.5, y.max()*0.9], fontsize=fts)     
plt.annotate('Slope='+str(round(b*100, 2))+'%', xytext=[xW.max()*0.75, y.max()*0.9], xy=[xW.max()*0.8, y.max()*0.9], fontsize=fts)
# use this when x is negative, and comment the other
#plt.annotate('Intercept='+str(round(m*100, 2))+'%', xytext=[xW.min()*0.3, y.max()*0.9], xy=[xW.min()*0.3, y.max()*0.9], fontsize=fts)     
#plt.annotate('Slope='+str(round(b*100, 2))+'%', xytext=[xW.min()*0.5, y.max()*0.9], xy=[xW.min()*0.5, y.max()*0.9], fontsize=fts)
plt.grid(True)
